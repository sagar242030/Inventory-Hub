-- Vendor Product Catalog & Purchase Order Portal (Excel download only; no email automation)
-- Apply once in Supabase SQL Editor. Review RLS policies before production use.

create extension if not exists pgcrypto;

do $$ begin
  create type public.app_role as enum ('admin', 'vendor', 'purchase_manager');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.item_status as enum ('submitted', 'approved', 'rejected', 'archived');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.po_status as enum ('created', 'cancelled');
exception when duplicate_object then null; end $$;

create sequence if not exists public.po_number_seq start 1;

create table if not exists public.vendors (
  id uuid primary key default gen_random_uuid(),
  vendor_code text unique,
  name text not null,
  email text not null,
  phone text,
  address text,
  gstin text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role public.app_role not null default 'vendor',
  vendor_id uuid references public.vendors(id) on delete restrict,
  created_at timestamptz not null default now(),
  constraint profile_vendor_role_check check (
    (role = 'vendor' and vendor_id is not null) or
    (role in ('admin', 'purchase_manager') and vendor_id is null)
  )
);

create table if not exists public.stores (
  id uuid primary key default gen_random_uuid(),
  store_code text not null unique,
  store_name text not null,
  address text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.items (
  id uuid primary key default gen_random_uuid(),
  vendor_id uuid not null references public.vendors(id) on delete restrict,
  vendor_sku text not null,
  item_name text not null,
  category text,
  rate numeric(12,2) not null check (rate >= 0),
  fabric text,
  colour text,
  size_range text,
  other_details text,
  image_path text,
  status public.item_status not null default 'submitted',
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (vendor_id, vendor_sku)
);

create index if not exists items_vendor_status_idx on public.items(vendor_id, status, created_at desc);
create index if not exists items_status_created_idx on public.items(status, created_at desc);

create table if not exists public.purchase_orders (
  id uuid primary key default gen_random_uuid(),
  po_number text not null unique,
  vendor_id uuid not null references public.vendors(id) on delete restrict,
  created_by uuid not null references auth.users(id) on delete restrict,
  status public.po_status not null default 'created',
  notes text,
  subtotal numeric(14,2) not null default 0 check (subtotal >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists purchase_orders_status_created_idx on public.purchase_orders(status, created_at);
create index if not exists purchase_orders_vendor_created_idx on public.purchase_orders(vendor_id, created_at desc);

create table if not exists public.purchase_order_lines (
  id uuid primary key default gen_random_uuid(),
  purchase_order_id uuid not null references public.purchase_orders(id) on delete cascade,
  item_id uuid not null references public.items(id) on delete restrict,
  store_id uuid not null references public.stores(id) on delete restrict,
  item_name_snapshot text not null,
  sku_snapshot text not null,
  rate_snapshot numeric(12,2) not null check (rate_snapshot >= 0),
  quantity integer not null check (quantity > 0),
  line_total numeric(14,2) generated always as (rate_snapshot * quantity) stored,
  created_at timestamptz not null default now()
);

create index if not exists po_lines_po_idx on public.purchase_order_lines(purchase_order_id);
create index if not exists po_lines_item_idx on public.purchase_order_lines(item_id);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists items_set_updated_at on public.items;
create trigger items_set_updated_at before update on public.items
for each row execute function public.set_updated_at();

drop trigger if exists purchase_orders_set_updated_at on public.purchase_orders;
create trigger purchase_orders_set_updated_at before update on public.purchase_orders
for each row execute function public.set_updated_at();

-- SECURITY DEFINER helpers avoid recursive RLS policies. They only return the
-- current authenticated user's role/vendor, never arbitrary users' profile data.
create or replace function public.current_app_role()
returns text language sql stable security definer set search_path = public
as $$ select p.role::text from public.profiles p where p.id = (select auth.uid()) $$;

create or replace function public.current_vendor_id()
returns uuid language sql stable security definer set search_path = public
as $$ select p.vendor_id from public.profiles p where p.id = (select auth.uid()) $$;

revoke all on function public.current_app_role() from public, anon;
revoke all on function public.current_vendor_id() from public, anon;
grant execute on function public.current_app_role() to authenticated, service_role;
grant execute on function public.current_vendor_id() to authenticated, service_role;

-- Atomic PO creation. Only purchase managers/admins can create POs. Each PO
-- belongs to one vendor but can include lines for multiple stores.
create or replace function public.create_purchase_order(
  p_vendor_id uuid,
  p_notes text,
  p_lines jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_order_id uuid;
  v_po_number text;
  v_line jsonb;
  v_item_id uuid;
  v_store_id uuid;
  v_quantity integer;
  v_item public.items%rowtype;
  v_subtotal numeric(14,2);
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;
  if coalesce(public.current_app_role(), '') not in ('purchase_manager', 'admin') then
    raise exception 'Only Purchase Manager/Admin can create purchase orders';
  end if;
  if p_lines is null or jsonb_typeof(p_lines) <> 'array' or jsonb_array_length(p_lines) = 0 then
    raise exception 'At least one PO line is required';
  end if;
  if not exists (select 1 from public.vendors v where v.id = p_vendor_id and v.is_active) then
    raise exception 'Vendor is not active or does not exist';
  end if;

  v_po_number := 'PO-' || to_char(now(), 'YYYYMMDD') || '-' || lpad(nextval('public.po_number_seq')::text, 5, '0');
  insert into public.purchase_orders(po_number, vendor_id, created_by, status, notes)
  values (v_po_number, p_vendor_id, auth.uid(), 'created', nullif(trim(p_notes), ''))
  returning id into v_order_id;

  for v_line in select value from jsonb_array_elements(p_lines) loop
    begin
      v_item_id := (v_line->>'item_id')::uuid;
      v_store_id := (v_line->>'store_id')::uuid;
      v_quantity := (v_line->>'quantity')::integer;
    exception when others then
      raise exception 'PO line has invalid item_id, store_id, or quantity';
    end;

    if v_quantity is null or v_quantity < 1 or v_quantity > 100000 then
      raise exception 'Quantity must be between 1 and 100000';
    end if;

    select * into v_item
    from public.items i
    where i.id = v_item_id
    for share;

    if not found then raise exception 'Item not found: %', v_item_id; end if;
    if v_item.vendor_id <> p_vendor_id then raise exception 'All PO items must belong to the selected vendor'; end if;
    if v_item.status <> 'approved' then raise exception 'Only approved items can be ordered'; end if;
    if not exists (select 1 from public.stores s where s.id = v_store_id and s.is_active) then
      raise exception 'Store is inactive or does not exist';
    end if;

    insert into public.purchase_order_lines(
      purchase_order_id, item_id, store_id, item_name_snapshot, sku_snapshot, rate_snapshot, quantity
    ) values (
      v_order_id, v_item.id, v_store_id, v_item.item_name, v_item.vendor_sku, v_item.rate, v_quantity
    );
  end loop;

  select coalesce(sum(pol.line_total), 0) into v_subtotal
  from public.purchase_order_lines pol where pol.purchase_order_id = v_order_id;

  update public.purchase_orders po set subtotal = v_subtotal, updated_at = now()
  where po.id = v_order_id;

  return jsonb_build_object(
    'id', v_order_id,
    'po_number', v_po_number,
    'vendor_id', p_vendor_id,
    'status', 'created',
    'subtotal', v_subtotal
  );
exception when others then
  if v_order_id is not null then
    delete from public.purchase_orders where id = v_order_id;
  end if;
  raise;
end;
$$;

revoke all on function public.create_purchase_order(uuid, text, jsonb) from public, anon;
grant execute on function public.create_purchase_order(uuid, text, jsonb) to authenticated;

-- Keep the item photographs private. Access to storage objects does not
-- inherit table RLS automatically; these policies are separate by design.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('item-photos', 'item-photos', false, 8388608, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

-- Tables are not publicly readable/writable. Authenticated client access is
-- granted explicitly and then filtered by RLS.
alter table public.profiles enable row level security;
alter table public.vendors enable row level security;
alter table public.stores enable row level security;
alter table public.items enable row level security;
alter table public.purchase_orders enable row level security;
alter table public.purchase_order_lines enable row level security;

revoke all on public.profiles, public.vendors, public.stores, public.items,
  public.purchase_orders, public.purchase_order_lines from anon, authenticated;

grant select on public.profiles to authenticated;
grant select on public.vendors to authenticated;
grant select on public.stores to authenticated;
grant select, insert, update, delete on public.items to authenticated;
grant select on public.purchase_orders to authenticated;
grant select on public.purchase_order_lines to authenticated;

-- Profiles: self or managers/admins can read. Role assignment should be done
-- only by an administrator in Supabase Auth/SQL, never from the client app.
drop policy if exists profiles_select_self_or_manager on public.profiles;
create policy profiles_select_self_or_manager on public.profiles for select to authenticated
using (id = (select auth.uid()) or (select public.current_app_role()) in ('purchase_manager','admin'));

drop policy if exists vendors_select_authorized on public.vendors;
create policy vendors_select_authorized on public.vendors for select to authenticated
using ((select public.current_app_role()) in ('purchase_manager','admin') or id = (select public.current_vendor_id()));

drop policy if exists stores_select_authenticated on public.stores;
create policy stores_select_authenticated on public.stores for select to authenticated
using (is_active or (select public.current_app_role()) in ('purchase_manager','admin'));

drop policy if exists items_select_authorized on public.items;
create policy items_select_authorized on public.items for select to authenticated
using ((select public.current_app_role()) in ('purchase_manager','admin') or vendor_id = (select public.current_vendor_id()));

drop policy if exists items_insert_own_vendor on public.items;
create policy items_insert_own_vendor on public.items for insert to authenticated
with check (
  (select public.current_app_role()) = 'vendor'
  and vendor_id = (select public.current_vendor_id())
  and created_by = (select auth.uid())
  and status = 'submitted'
);

drop policy if exists items_update_authorized on public.items;
create policy items_update_authorized on public.items for update to authenticated
using (
  (select public.current_app_role()) in ('purchase_manager','admin')
  or (vendor_id = (select public.current_vendor_id()) and created_by = (select auth.uid()) and status = 'submitted')
)
with check (
  (select public.current_app_role()) in ('purchase_manager','admin')
  or (vendor_id = (select public.current_vendor_id()) and created_by = (select auth.uid()) and status = 'submitted')
);

drop policy if exists items_delete_authorized on public.items;
create policy items_delete_authorized on public.items for delete to authenticated
using (
  (select public.current_app_role()) in ('purchase_manager','admin')
  or (vendor_id = (select public.current_vendor_id()) and created_by = (select auth.uid()) and status = 'submitted')
);

drop policy if exists po_select_authorized on public.purchase_orders;
create policy po_select_authorized on public.purchase_orders for select to authenticated
using (
  (select public.current_app_role()) in ('purchase_manager','admin')
  or (vendor_id = (select public.current_vendor_id()) and status = 'created')
);

drop policy if exists po_lines_select_authorized on public.purchase_order_lines;
create policy po_lines_select_authorized on public.purchase_order_lines for select to authenticated
using (exists (
  select 1 from public.purchase_orders po
  where po.id = purchase_order_lines.purchase_order_id
  and (
    (select public.current_app_role()) in ('purchase_manager','admin')
    or (po.vendor_id = (select public.current_vendor_id()) and po.status = 'created')
  )
));

-- Storage paths are stored as <auth-user-id>/<unique-file-name>.
drop policy if exists item_photo_upload_own_folder on storage.objects;
create policy item_photo_upload_own_folder on storage.objects for insert to authenticated
with check (
  bucket_id = 'item-photos'
  and (storage.foldername(name))[1] = (select auth.uid())::text
  and (select public.current_app_role()) = 'vendor'
);

drop policy if exists item_photo_read_authorized on storage.objects;
create policy item_photo_read_authorized on storage.objects for select to authenticated
using (
  bucket_id = 'item-photos'
  and (
    (storage.foldername(name))[1] = (select auth.uid())::text
    or (select public.current_app_role()) in ('purchase_manager','admin')
  )
);

-- Optional starting records: add your actual company stores/vendors separately.
-- After creating a user in Supabase Auth, add the matching profile. Example:
-- insert into public.profiles(id, full_name, role, vendor_id)
-- values ('AUTH-USER-UUID', 'Purchase Manager Name', 'purchase_manager', null);
-- For a vendor user, set role='vendor' and vendor_id to that vendor record.
