# VendorHub Test Plan

Run these checks in a non-production Supabase project before go-live.

## 1. Login and role permissions

- Sign in as a Purchase Manager and as a vendor test account.
- Confirm the Purchase Manager sees the buying catalogue, vendor-wise purchase orders, vendor directory and stores.
- Confirm each vendor can see only its own item submissions and its own purchase orders.
- Confirm an unauthenticated visitor cannot read or change company records.

## 2. Item submission and approval

- Upload a test item with an image, SKU, name, rate, fabric and colour as Vendor A.
- Confirm Vendor A sees it and Vendor B does not.
- Confirm the item starts as `submitted` and cannot be selected for a PO until approved.
- Approve the item as a Purchase Manager and confirm its status changes to `approved`.

## 3. Purchase order creation

- Select approved items from one vendor, enter a positive quantity and choose a valid active store.
- Create the PO and confirm the returned PO number has the format `PO-YYYYMMDD-00001` (sequence can differ).
- Select approved items from more than one vendor in one action. Confirm the application creates one separate PO per vendor.
- Confirm every PO line preserves SKU, item name, rate, quantity and store association, and the subtotal equals the sum of line totals.
- Confirm zero/negative quantities, inactive stores and unapproved items are rejected.

## 4. Excel download

- In demo preview, click the download icon on a purchase order and confirm a `.xlsx` file downloads and opens in Excel or LibreOffice.
- In connected mode, repeat with a newly created PO. Confirm all PO lines are fetched from Supabase and included in the workbook.
- Verify PO Number, PO Date, Vendor Name/Code/Phone/GSTIN/Address, notes, Store Code, Store Name, SKU, Item Name, Quantity, Rate, Line Total and GRAND TOTAL.
- Verify currency values are numeric and the total matches the database PO subtotal.
- Verify each PO produces a separate Excel file named with its PO number.
- Confirm no email is sent or attempted; no SMTP credentials or n8n workflow should be configured for PO download.

## 5. Photo and data security

- Confirm vendor photos are stored in the private `item-photos` bucket.
- Confirm Vendor A cannot upload into Vendor B's folder or access Vendor B's photos.
- Test unauthorized reads and writes for every table/policy before production use.
