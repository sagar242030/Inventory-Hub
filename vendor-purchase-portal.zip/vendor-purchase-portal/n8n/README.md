# n8n integration intentionally not used for PO Excel

This version generates and downloads `.xlsx` directly from the Purchase Orders screen in the browser. No email, SMTP, mail node, n8n workflow or service-role key is needed for this task. Keep n8n out of the PO-download path unless a future requirement explicitly adds a background automation.
