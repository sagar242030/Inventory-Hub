import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity, ArrowDownRight, ArrowRight, BadgeCheck, Bell, Boxes, Building2,
  Check, CheckCircle2, ChevronDown, CircleHelp, ClipboardList, Clock3,
  Download, Eye, FileSpreadsheet, Filter, ImagePlus, LogOut, Mail, Package,
  Plus, Search, Send, ShieldCheck, ShoppingBag, Store, TrendingUp, Upload,
  Users, X, XCircle
} from 'lucide-react';
import { isSupabaseConfigured, supabase } from './lib';
import * as XLSX from 'xlsx';

const demoVendors = [
  { id: 'vendor-1', name: 'Shree Textiles', email: 'orders@shreetextiles.example', vendor_code: 'V-001' },
  { id: 'vendor-2', name: 'Mahalaxmi Fashion', email: 'sales@mahalaxmifashion.example', vendor_code: 'V-002' },
  { id: 'vendor-3', name: 'Aarohi Fabrics', email: 'contact@aarohifabrics.example', vendor_code: 'V-003' }
];
const demoStores = [
  { id: 'store-1', store_code: 'PUN-01', store_name: 'Pune - Main Store' },
  { id: 'store-2', store_code: 'MUM-01', store_name: 'Mumbai - Andheri' },
  { id: 'store-3', store_code: 'BRS-01', store_name: 'Barshi Branch' },
  { id: 'store-4', store_code: 'SHR-01', store_name: 'Shirur Branch' }
];
const demoItems = [
  { id: 'item-1', vendor_id: 'vendor-1', vendor: demoVendors[0], vendor_sku: 'ST-2841', item_name: 'Banarasi Soft Silk Saree', category: 'Saree', rate: 1450, fabric: 'Soft Silk', colour: 'Wine / Gold', status: 'approved', other_details: 'Jacquard weave, festive collection', created_at: '2026-10-28T08:20:00Z', image_path: '' },
  { id: 'item-2', vendor_id: 'vendor-1', vendor: demoVendors[0], vendor_sku: 'ST-2842', item_name: 'Cotton Floral Daily Wear', category: 'Saree', rate: 690, fabric: 'Cotton', colour: 'Teal / Cream', status: 'approved', other_details: 'Lightweight, easy-care fabric', created_at: '2026-10-27T11:00:00Z', image_path: '' },
  { id: 'item-3', vendor_id: 'vendor-2', vendor: demoVendors[1], vendor_sku: 'MF-1038', item_name: 'Embroidered Festive Suit', category: 'Suit Set', rate: 1890, fabric: 'Chanderi Blend', colour: 'Mustard', status: 'submitted', other_details: 'Dupatta included', created_at: '2026-10-28T07:40:00Z', image_path: '' },
  { id: 'item-4', vendor_id: 'vendor-3', vendor: demoVendors[2], vendor_sku: 'AF-7782', item_name: 'Linen Blend Kurta Fabric', category: 'Fabric', rate: 420, fabric: 'Linen Blend', colour: 'Indigo', status: 'submitted', other_details: 'Width 44 inches', created_at: '2026-10-26T13:30:00Z', image_path: '' },
  { id: 'item-5', vendor_id: 'vendor-2', vendor: demoVendors[1], vendor_sku: 'MF-1044', item_name: 'Printed Rayon Co-ord Set', category: 'Western Wear', rate: 880, fabric: 'Rayon', colour: 'Olive / Black', status: 'approved', other_details: 'S to XXL, new-season print', created_at: '2026-10-25T08:30:00Z', image_path: '' }
];

const money = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(Number(n || 0));
const shortDate = (date) => date ? new Date(date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
const initials = (name = '') => name.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join('').toUpperCase() || 'VH';

export default function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [authLoading, setAuthLoading] = useState(isSupabaseConfigured);
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [demoMode, setDemoMode] = useState(!isSupabaseConfigured);
  const [role, setRole] = useState('purchase_manager');
  const [activeView, setActiveView] = useState('overview');
  const [items, setItems] = useState(demoItems);
  const [vendors, setVendors] = useState(demoVendors);
  const [stores, setStores] = useState(demoStores);
  const [purchaseOrders, setPurchaseOrders] = useState([
    { id: 'po-1', po_number: 'PO-20261027-00021', status: 'created', vendor_id: 'vendor-1', vendor: demoVendors[0], subtotal: 29000, created_at: '2026-10-27T09:00:00Z', lines: 1, demoLines: [{ vendor_sku: 'ST-2841', item_name: 'Banarasi Soft Silk Saree', quantity: 20, rate: 1450, store_code: 'PUN-01', store_name: 'Pune - Main Store' }] },
    { id: 'po-2', po_number: 'PO-20261026-00020', status: 'created', vendor_id: 'vendor-3', vendor: demoVendors[2], subtotal: 17640, created_at: '2026-10-26T10:30:00Z', lines: 1, demoLines: [{ vendor_sku: 'AF-7782', item_name: 'Linen Blend Kurta Fabric', quantity: 42, rate: 420, store_code: 'MUM-01', store_name: 'Mumbai - Andheri' }] },
    { id: 'po-3', po_number: 'PO-20261024-00019', status: 'created', vendor_id: 'vendor-2', vendor: demoVendors[1], subtotal: 22400, created_at: '2026-10-24T08:45:00Z', lines: 1, demoLines: [{ vendor_sku: 'MF-DEMO-01', item_name: 'Sample Festive Collection', quantity: 10, rate: 2240, store_code: 'BRS-01', store_name: 'Barshi Branch' }] }
  ]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [vendorFilter, setVendorFilter] = useState('all');
  const [selected, setSelected] = useState({});
  const [notes, setNotes] = useState('');
  const [showAddItem, setShowAddItem] = useState(false);
  const [toast, setToast] = useState('');
  const [busy, setBusy] = useState(false);
  const [itemForm, setItemForm] = useState({ vendor_sku: '', item_name: '', category: 'Saree', rate: '', fabric: '', colour: '', size_range: '', other_details: '' });
  const [itemPhoto, setItemPhoto] = useState(null);
  const [photoUrls, setPhotoUrls] = useState({});
  const fileRef = useRef(null);

  const isManager = role === 'purchase_manager' || role === 'admin';
  const userName = profile?.full_name || (role === 'vendor' ? 'Vendor Account' : 'Purchase Manager');
  const userVendorId = profile?.vendor_id;
  const userVendor = vendors.find(v => v.id === userVendorId) || vendors[0];

  useEffect(() => {
    if (!supabase) return;
    let alive = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!alive) return;
      setSession(data.session);
      if (data.session) loadProfile(data.session.user.id);
      else setAuthLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!alive) return;
      setSession(nextSession);
      if (nextSession) loadProfile(nextSession.user.id);
      else { setProfile(null); setAuthLoading(false); }
    });
    return () => { alive = false; listener.subscription.unsubscribe(); };
  }, []);

  useEffect(() => {
    if (session && profile) loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, profile]);

  async function loadProfile(userId) {
    setAuthLoading(true);
    const { data, error } = await supabase.from('profiles').select('id, full_name, role, vendor_id').eq('id', userId).single();
    if (error || !data) {
      setAuthError('Profile missing. Ask the administrator to create your role in Supabase before signing in.');
      await supabase.auth.signOut();
      setAuthLoading(false);
      return;
    }
    setProfile(data);
    setRole(data.role);
    setActiveView('overview');
    setAuthError('');
    setAuthLoading(false);
  }

  async function loadData() {
    if (!supabase || !profile) return;
    const [itemResp, vendorResp, storeResp, poResp] = await Promise.all([
      supabase.from('items').select('*, vendors(id,name,email,vendor_code)').order('created_at', { ascending: false }),
      supabase.from('vendors').select('id,name,email,vendor_code').order('name'),
      supabase.from('stores').select('id,store_code,store_name,is_active').eq('is_active', true).order('store_name'),
      supabase.from('purchase_orders').select('*, vendors(id,name,email,vendor_code,phone,address,gstin), purchase_order_lines(id)').order('created_at', { ascending: false }).limit(30)
    ]);
    if (!itemResp.error && itemResp.data) setItems(itemResp.data.map(i => ({ ...i, vendor: i.vendors || vendors.find(v => v.id === i.vendor_id) })));
    if (!vendorResp.error && vendorResp.data) setVendors(vendorResp.data);
    if (!storeResp.error && storeResp.data) setStores(storeResp.data);
    if (!poResp.error && poResp.data) setPurchaseOrders(poResp.data.map(po => ({ ...po, vendor: po.vendors || vendors.find(v => v.id === po.vendor_id), lines: po.purchase_order_lines?.length || 0 })));
  }

  useEffect(() => {
    if (!supabase || !items.length) return;
    let canceled = false;
    async function resolveImages() {
      const pending = items.filter(i => i.image_path && !photoUrls[i.id]);
      if (!pending.length) return;
      const newUrls = {};
      await Promise.all(pending.map(async i => {
        const { data } = await supabase.storage.from('item-photos').createSignedUrl(i.image_path, 3600);
        if (data?.signedUrl) newUrls[i.id] = data.signedUrl;
      }));
      if (!canceled && Object.keys(newUrls).length) setPhotoUrls(prev => ({ ...prev, ...newUrls }));
    }
    resolveImages();
    return () => { canceled = true; };
  }, [items, photoUrls]);

  useEffect(() => {
    if (!toast) return;
    const timeout = setTimeout(() => setToast(''), 4200);
    return () => clearTimeout(timeout);
  }, [toast]);

  const visibleItems = useMemo(() => items.filter(item => {
    const q = search.trim().toLowerCase();
    const matchesSearch = !q || [item.item_name, item.vendor_sku, item.fabric, item.colour, item.category, item.vendor?.name].some(v => String(v || '').toLowerCase().includes(q));
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchesVendor = vendorFilter === 'all' || item.vendor_id === vendorFilter;
    const matchesRole = isManager || item.vendor_id === userVendorId;
    return matchesSearch && matchesStatus && matchesVendor && matchesRole;
  }), [items, search, statusFilter, vendorFilter, isManager, userVendorId]);

  const stats = useMemo(() => ({
    total: items.filter(i => isManager || i.vendor_id === userVendorId).length,
    pending: items.filter(i => i.status === 'submitted' && (isManager || i.vendor_id === userVendorId)).length,
    approved: items.filter(i => i.status === 'approved' && (isManager || i.vendor_id === userVendorId)).length,
    orders: purchaseOrders.filter(po => isManager || po.vendor_id === userVendorId).length,
    spend: purchaseOrders.filter(po => po.status === 'created' && (isManager || po.vendor_id === userVendorId)).reduce((n, po) => n + Number(po.subtotal || 0), 0)
  }), [items, purchaseOrders, isManager, userVendorId]);

  async function signIn(e) {
    e.preventDefault(); setBusy(true); setAuthError('');
    const { error } = await supabase.auth.signInWithPassword({ email: authEmail, password: authPassword });
    if (error) setAuthError(error.message);
    setBusy(false);
  }

  async function logout() {
    if (supabase && session) await supabase.auth.signOut();
    setSession(null); setProfile(null); setDemoMode(false); setRole('purchase_manager'); setActiveView('overview');
  }

  function demoSignIn(nextRole) {
    setRole(nextRole); setDemoMode(true); setProfile(nextRole === 'vendor' ? { full_name: 'Shree Textiles', vendor_id: 'vendor-1' } : { full_name: 'Purchase Manager' });
    setActiveView('overview');
  }

  async function saveItem(e) {
    e.preventDefault();
    if (!itemForm.vendor_sku.trim() || !itemForm.item_name.trim() || itemForm.rate === '') { setToast('Please fill SKU, item name and rate.'); return; }
    setBusy(true);
    try {
      if (!supabase || demoMode) {
        const vendor = userVendor;
        const item = { ...itemForm, id: `item-${Date.now()}`, vendor_id: vendor.id, vendor, rate: Number(itemForm.rate), status: 'submitted', created_at: new Date().toISOString(), image_path: '', demoPhoto: itemPhoto ? URL.createObjectURL(itemPhoto) : '' };
        setItems(prev => [item, ...prev]);
      } else {
        let image_path = null;
        if (itemPhoto) {
          const extension = itemPhoto.name.split('.').pop()?.toLowerCase() || 'jpg';
          image_path = `${session.user.id}/${crypto.randomUUID()}.${extension}`;
          const { error: uploadError } = await supabase.storage.from('item-photos').upload(image_path, itemPhoto, { contentType: itemPhoto.type, upsert: false });
          if (uploadError) throw uploadError;
        }
        const { error } = await supabase.from('items').insert({
          vendor_id: profile.vendor_id, created_by: session.user.id,
          vendor_sku: itemForm.vendor_sku.trim(), item_name: itemForm.item_name.trim(), category: itemForm.category,
          rate: Number(itemForm.rate), fabric: itemForm.fabric.trim() || null, colour: itemForm.colour.trim() || null,
          size_range: itemForm.size_range.trim() || null, other_details: itemForm.other_details.trim() || null,
          image_path, status: 'submitted'
        });
        if (error) throw error;
        await loadData();
      }
      setItemForm({ vendor_sku: '', item_name: '', category: 'Saree', rate: '', fabric: '', colour: '', size_range: '', other_details: '' });
      setItemPhoto(null); setShowAddItem(false); setToast('New item submitted to the Purchase Manager.');
    } catch (error) { setToast(error.message || 'Could not save item.'); }
    finally { setBusy(false); }
  }

  async function changeItemStatus(item, nextStatus) {
    try {
      if (!supabase || demoMode) setItems(prev => prev.map(i => i.id === item.id ? { ...i, status: nextStatus } : i));
      else {
        const { error } = await supabase.from('items').update({ status: nextStatus }).eq('id', item.id);
        if (error) throw error;
        await loadData();
      }
      setToast(`${item.item_name}: ${nextStatus}.`);
    } catch (error) { setToast(error.message || 'Status update failed.'); }
  }

  function updateSelection(itemId, patch) {
    setSelected(prev => ({ ...prev, [itemId]: { quantity: prev[itemId]?.quantity || 1, store_id: prev[itemId]?.store_id || stores[0]?.id || '', checked: prev[itemId]?.checked || false, ...patch } }));
  }

  async function createPurchaseOrders() {
    const chosen = items.filter(item => selected[item.id]?.checked && item.status === 'approved');
    if (!chosen.length) { setToast('Select at least one approved item.'); return; }
    if (chosen.some(item => !selected[item.id]?.store_id || Number(selected[item.id]?.quantity) < 1)) { setToast('Set a store and quantity for every selected item.'); return; }
    const groups = chosen.reduce((map, item) => { (map[item.vendor_id] ||= []).push(item); return map; }, {});
    setBusy(true);
    try {
      const newOrders = [];
      for (const [vendorId, groupItems] of Object.entries(groups)) {
        const lines = groupItems.map(item => ({ item_id: item.id, quantity: Number(selected[item.id].quantity), store_id: selected[item.id].store_id }));
        const vendor = vendors.find(v => v.id === vendorId) || groupItems[0].vendor;
        if (!supabase || demoMode) {
          const total = groupItems.reduce((sum, item) => sum + Number(item.rate) * Number(selected[item.id].quantity), 0);
          newOrders.push({ id: `po-${Date.now()}-${vendorId}`, po_number: `PO-${new Date().toISOString().slice(0,10).replaceAll('-','')}-${String(purchaseOrders.length + newOrders.length + 1).padStart(5, '0')}`, status: 'created', vendor_id: vendorId, vendor, subtotal: total, notes, created_at: new Date().toISOString(), lines: groupItems.length, demoLines: groupItems.map(item => { const store = stores.find(s => s.id === selected[item.id].store_id); return { ...item, quantity: Number(selected[item.id].quantity), store_name: store?.store_name || '', store_code: store?.store_code || '' }; }) });
        } else {
          const { data, error } = await supabase.rpc('create_purchase_order', { p_vendor_id: vendorId, p_notes: notes, p_lines: lines });
          if (error) throw error;
          const po = Array.isArray(data) ? data[0] : data;
          newOrders.push({ ...po, vendor_id: vendorId, vendor, created_at: new Date().toISOString(), lines: groupItems.length });
        }
      }
      setPurchaseOrders(prev => [...newOrders, ...prev]);
      setSelected({}); setNotes(''); setActiveView('orders');
      setToast(`${newOrders.length} Purchase Order(s) created. Open Purchase Orders and click Download Excel for each vendor.`);
      if (supabase && !demoMode) await loadData();
    } catch (error) { setToast(error.message || 'PO creation failed.'); }
    finally { setBusy(false); }
  }

  async function downloadPurchaseOrder(po) {
    setBusy(true);
    try {
      let lines = Array.isArray(po.demoLines) ? po.demoLines : [];

      if (supabase && !demoMode) {
        const { data, error } = await supabase
          .from('purchase_order_lines')
          .select('sku_snapshot,item_name_snapshot,quantity,rate_snapshot,line_total,stores(store_code,store_name)')
          .eq('purchase_order_id', po.id)
          .order('created_at', { ascending: true });
        if (error) throw error;
        lines = (data || []).map(line => ({
          vendor_sku: line.sku_snapshot,
          item_name: line.item_name_snapshot,
          quantity: Number(line.quantity || 0),
          rate: Number(line.rate_snapshot || 0),
          line_total: Number(line.line_total || Number(line.quantity || 0) * Number(line.rate_snapshot || 0)),
          store_code: line.stores?.store_code || '',
          store_name: line.stores?.store_name || ''
        }));
      }

      // The preloaded demo register uses representative order lines so the Excel download can be previewed without a database.
      if (!lines.length && (!supabase || demoMode)) {
        lines = [{
          vendor_sku: 'DEMO-PO-LINE',
          item_name: 'Sample purchase order line',
          quantity: 1,
          rate: Number(po.subtotal || 0),
          line_total: Number(po.subtotal || 0),
          store_code: demoStores[0]?.store_code || '',
          store_name: demoStores[0]?.store_name || 'Demo Store'
        }];
      }
      if (!lines.length) throw new Error('No item lines were found for this purchase order.');

      const vendor = po.vendor || {};
      const created = po.created_at ? new Date(po.created_at) : new Date();
      const dataRows = lines.map((line, index) => [
        index + 1,
        line.store_code || '',
        line.store_name || '',
        line.vendor_sku || line.sku_snapshot || '',
        line.item_name || line.item_name_snapshot || '',
        Number(line.quantity || 0),
        Number(line.rate || line.rate_snapshot || 0),
        Number(line.line_total ?? (Number(line.quantity || 0) * Number(line.rate || line.rate_snapshot || 0)))
      ]);
      const totalQty = lines.reduce((sum, line) => sum + Number(line.quantity || 0), 0);
      const totalValue = dataRows.reduce((sum, row) => sum + Number(row[7] || 0), 0);

      const rows = [
        ['PURCHASE ORDER'],
        ['PO Number', po.po_number || '', '', 'PO Date', created],
        ['Vendor Name', vendor.name || '', '', 'Vendor Code', vendor.vendor_code || ''],
        ['Vendor Phone', vendor.phone || '', '', 'Vendor GSTIN', vendor.gstin || ''],
        ['Vendor Address', vendor.address || '', '', 'PO Notes', po.notes || ''],
        [],
        ['Sr. No.', 'Store Code', 'Store Name', 'Item SKU', 'Item Name', 'Quantity', 'Rate (INR)', 'Line Total (INR)'],
        ...dataRows,
        ['', '', '', '', 'GRAND TOTAL', totalQty, '', totalValue]
      ];
      const workbook = XLSX.utils.book_new();
      const worksheet = XLSX.utils.aoa_to_sheet(rows);
      worksheet['!merges'] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 7 } }];
      worksheet['!cols'] = [
        { wch: 9 }, { wch: 13 }, { wch: 25 }, { wch: 17 },
        { wch: 33 }, { wch: 12 }, { wch: 16 }, { wch: 18 }
      ];
      worksheet['!rows'] = [{ hpt: 26 }, { hpt: 22 }];
      const finalExcelRow = 7 + lines.length;
      worksheet['!autofilter'] = { ref: `A7:H${7 + lines.length}` };
      if (worksheet.E2) worksheet.E2.z = 'dd-mmm-yyyy';
      for (let r = 7; r < 7 + lines.length; r += 1) {
        const rateCell = worksheet[XLSX.utils.encode_cell({ r, c: 6 })];
        const totalCell = worksheet[XLSX.utils.encode_cell({ r, c: 7 })];
        if (rateCell) rateCell.z = '₹#,##0.00';
        if (totalCell) totalCell.z = '₹#,##0.00';
      }
      const grandTotalCell = worksheet[XLSX.utils.encode_cell({ r: finalExcelRow, c: 7 })];
      if (grandTotalCell) grandTotalCell.z = '₹#,##0.00';
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Purchase Order');
      XLSX.writeFileXLSX(workbook, `${po.po_number || 'Purchase-Order'}.xlsx`);
      setToast(`Excel file downloaded: ${po.po_number}.xlsx`);
    } catch (error) {
      setToast(error.message || 'Could not generate the Purchase Order Excel file.');
    } finally {
      setBusy(false);
    }
  }

  const navItems = isManager ? [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'catalog', label: 'Item Catalog', icon: Boxes, badge: items.filter(i => i.status === 'submitted').length || null },
    { id: 'orders', label: 'Purchase Orders', icon: FileSpreadsheet },
    { id: 'vendors', label: 'Vendors & Stores', icon: Building2 }
  ] : [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'my-items', label: 'My Items', icon: Package },
    { id: 'orders', label: 'My Purchase Orders', icon: ClipboardList }
  ];

  if (isSupabaseConfigured && !session && !demoMode) {
    return <LoginScreen email={authEmail} setEmail={setAuthEmail} password={authPassword} setPassword={setAuthPassword} onSubmit={signIn} busy={busy || authLoading} error={authError} onDemo={demoSignIn} />;
  }
  if (authLoading && isSupabaseConfigured && !demoMode) return <div className="loading-screen"><span className="brand-mark">VH</span><p>Connecting to VendorHub...</p></div>;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-lockup"><div className="brand-mark">VH</div><div><div className="brand-name">VendorHub</div><div className="brand-caption">MERCHANDISE PORTAL</div></div></div>
        <div className="workspace-label">WORKSPACE</div>
        <nav className="nav-list">
          {navItems.map(({ id, label, icon: Icon, badge }) => <button key={id} className={`nav-item ${activeView === id ? 'active' : ''}`} onClick={() => setActiveView(id)}><Icon size={18} strokeWidth={1.8} /><span>{label}</span>{badge ? <span className="nav-badge">{badge}</span> : null}</button>)}
        </nav>
        {isManager && <div className="sidebar-bottom-card"><div className="sidebar-icon"><ShieldCheck size={18} /></div><div><strong>Buying workflow</strong><p>Review items, create vendor-wise POs, and download Excel files.</p></div></div>}
        <div className="sidebar-footer"><div className="help-dot"><CircleHelp size={17} /></div><div><strong>Need help?</strong><span>Contact IT Support</span></div><ArrowRight size={15} className="help-arrow" /></div>
      </aside>

      <main className="main-shell">
        <header className="topbar">
          <div className="breadcrumb"><span>Workspace</span><span className="slash">/</span><strong>{navItems.find(n => n.id === activeView)?.label || 'Overview'}</strong></div>
          <div className="topbar-actions">
            {demoMode && <><span className="demo-pill"><span className="demo-dot" /> Demo preview</span><button className="switch-role-btn" onClick={() => demoSignIn(role === 'vendor' ? 'purchase_manager' : 'vendor')}>Switch to {role === 'vendor' ? 'Manager' : 'Vendor'}</button></>}
            <button className="icon-button notification-button" aria-label="Notifications" onClick={() => setToast('You are all caught up.')}><Bell size={18} /><i /></button>
            <div className="topbar-divider" />
            <div className="user-chip"><div className="avatar">{initials(userName)}</div><div className="user-meta"><strong>{userName}</strong><span>{roleLabel(role)}</span></div><ChevronDown size={15} className="muted" /></div>
            <button className="icon-button logout-btn" aria-label="Sign out" title="Sign out / switch demo role" onClick={logout}><LogOut size={17} /></button>
          </div>
        </header>

        <div className="page-content">
          {activeView === 'overview' && <Overview role={role} stats={stats} items={items} purchaseOrders={purchaseOrders} vendors={vendors} onNavigate={setActiveView} onStatus={changeItemStatus} />}
          {(activeView === 'catalog' || activeView === 'my-items') && <CatalogPage isManager={isManager} items={visibleItems} allItems={items} vendors={vendors} search={search} setSearch={setSearch} statusFilter={statusFilter} setStatusFilter={setStatusFilter} vendorFilter={vendorFilter} setVendorFilter={setVendorFilter} selected={selected} updateSelection={updateSelection} stores={stores} onStatus={changeItemStatus} onAdd={() => setShowAddItem(true)} onCreatePO={createPurchaseOrders} busy={busy} photoUrls={photoUrls} notes={notes} setNotes={setNotes} role={role} />}
          {activeView === 'orders' && <OrdersPage isManager={isManager} orders={purchaseOrders.filter(po => isManager || po.vendor_id === userVendorId)} onDownload={downloadPurchaseOrder} />}
          {activeView === 'vendors' && <VendorsStoresPage vendors={vendors} stores={stores} />}
        </div>
      </main>

      {showAddItem && <AddItemModal form={itemForm} setForm={setItemForm} photo={itemPhoto} setPhoto={setItemPhoto} fileRef={fileRef} onClose={() => setShowAddItem(false)} onSubmit={saveItem} busy={busy} vendor={userVendor} />}
      {toast && <div className="toast"><CheckCircle2 size={18} /><span>{toast}</span><button aria-label="Dismiss" onClick={() => setToast('')}><X size={16} /></button></div>}
    </div>
  );
}

function roleLabel(role) { return role === 'purchase_manager' ? 'Purchase Manager' : role === 'admin' ? 'Administrator' : 'Vendor Partner'; }

function LoginScreen({ email, setEmail, password, setPassword, onSubmit, busy, error, onDemo }) {
  return <div className="login-layout"><section className="login-story"><div className="brand-lockup"><div className="brand-mark">VH</div><div><div className="brand-name">VendorHub</div><div className="brand-caption">MERCHANDISE PORTAL</div></div></div><div className="login-hero-content"><span className="eyebrow"><span className="eyebrow-dot" /> BUYING, SIMPLIFIED</span><h1>From new arrivals to purchase orders.<em> One connected workflow.</em></h1><p>A clear, collaborative space for vendors to share their latest collections and for buying teams to build store-ready purchase orders.</p><div className="login-feature-list"><div><CheckCircle2 size={18} /><span>Centralised product submissions</span></div><div><CheckCircle2 size={18} /><span>Store-wise buying quantities</span></div><div><CheckCircle2 size={18} /><span>Downloadable vendor-wise Excel purchase orders</span></div></div></div><div className="login-story-footer"><span>INTERNAL BUYING PLATFORM</span><span>SECURE BY DESIGN</span></div></section><section className="login-form-side"><div className="login-form-wrap"><div className="mobile-brand"><div className="brand-mark">VH</div><div className="brand-name">VendorHub</div></div><span className="login-kicker">WELCOME BACK</span><h2>Sign in to your workspace</h2><p className="login-subtitle">Enter your company-provided credentials to continue.</p><form className="login-form" onSubmit={onSubmit}><label>Email address</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@company.com" required autoComplete="username" /><label>Password</label><input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter your password" required autoComplete="current-password" />{error && <div className="auth-error">{error}</div>}<button className="primary-btn login-submit" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'} <ArrowRight size={17} /></button></form><div className="login-security"><ShieldCheck size={17} /><span>Access is managed by your company administrator.</span></div><div className="demo-login"><div className="demo-login-title">Explore a demo preview</div><div className="demo-login-actions"><button onClick={() => onDemo('purchase_manager')}>Purchase Manager</button><button onClick={() => onDemo('vendor')}>Vendor</button></div></div><div className="login-legal">© 2026 VendorHub · Internal use only</div></div></section></div>;
}

function Overview({ role, stats, items, purchaseOrders, vendors, onNavigate, onStatus }) {
  const manager = role !== 'vendor';
  const recentItems = items.slice().sort((a,b) => new Date(b.created_at) - new Date(a.created_at)).slice(0,4);
  const recentOrders = purchaseOrders.slice().sort((a,b) => new Date(b.created_at) - new Date(a.created_at)).slice(0,4);
  return <>
    <div className="page-heading-row"><div><div className="page-eyebrow">{manager ? 'BUYING OPERATIONS' : 'VENDOR WORKSPACE'}</div><h1>{manager ? 'Good morning, team' : 'Your product workspace'}</h1><p>{manager ? 'Here’s what’s happening across your vendor buying pipeline.' : 'Keep your latest items and product details ready for the buying team.'}</p></div>{manager ? <button className="primary-btn" onClick={() => onNavigate('catalog')}><Package size={17} /> Review item catalog</button> : <button className="primary-btn" onClick={() => onNavigate('my-items')}><Plus size={17} /> Manage my items</button>}</div>
    <div className="stat-grid">
      <StatCard icon={Package} label={manager ? 'Total listed items' : 'My submitted items'} value={stats.total} detail={manager ? 'Across all active vendors' : 'Products in your catalogue'} tone="mint" />
      <StatCard icon={Clock3} label={manager ? 'Awaiting review' : 'Pending review'} value={stats.pending} detail={manager ? 'Need your attention' : 'With the buying team'} tone="amber" />
      <StatCard icon={BadgeCheck} label={manager ? 'Approved items' : 'Approved by buying'} value={stats.approved} detail="Ready for selection" tone="blue" />
      <StatCard icon={FileSpreadsheet} label={manager ? 'Purchase orders' : 'Orders received'} value={stats.orders} detail={manager ? 'Created in this workspace' : 'Orders visible to your account'} tone="violet" />
    </div>
    {manager && <section className="insight-banner"><div className="insight-symbol"><TrendingUp size={21} /></div><div className="insight-copy"><strong>Keep buying decisions moving</strong><p>{stats.pending ? `${stats.pending} item(s) are waiting for a review.` : 'No items are waiting for review right now.'} Approve the right items, then create vendor-wise purchase orders.</p></div><button className="text-btn" onClick={() => onNavigate('catalog')}>Open catalog <ArrowRight size={15} /></button><div className="insight-art"><span /><span /><span /><span /><span /></div></section>}
    <div className="overview-grid"><section className="panel recent-panel"><div className="panel-header"><div><h2>{manager ? 'Recently submitted items' : 'Your recent items'}</h2><p>Latest updates from the product catalogue</p></div><button className="text-btn" onClick={() => onNavigate(manager ? 'catalog' : 'my-items')}>View all <ArrowRight size={15} /></button></div><div className="table-wrap"><table className="data-table"><thead><tr><th>Product</th>{manager && <th>Vendor</th>}<th>Rate</th><th>Status</th><th>Submitted</th>{manager && <th aria-label="Actions" />}</tr></thead><tbody>{recentItems.map(item => <tr key={item.id}><td><ProductCell item={item} /></td>{manager && <td><span className="vendor-inline"><span className="mini-avatar">{initials(item.vendor?.name)}</span>{item.vendor?.name || 'Vendor'}</span></td>}<td className="rate-cell">{money(item.rate)}</td><td><StatusPill status={item.status} /></td><td className="muted-cell">{shortDate(item.created_at)}</td>{manager && <td>{item.status === 'submitted' ? <button className="small-approve" onClick={() => onStatus(item, 'approved')}><Check size={14} /> Approve</button> : <span className="muted-cell">—</span>}</td>}</tr>)}</tbody></table>{!recentItems.length && <EmptyState title="No items yet" text="Product submissions will appear here." />}</div></section><section className="panel order-panel"><div className="panel-header"><div><h2>Recent purchase orders</h2><p>Vendor-wise order activity</p></div><button className="text-btn" onClick={() => onNavigate('orders')}>View all <ArrowRight size={15} /></button></div><div className="order-list">{recentOrders.map(po => <div className="order-list-row" key={po.id}><div className="po-icon"><FileSpreadsheet size={17} /></div><div className="po-info"><strong>{po.po_number}</strong><span>{po.vendor?.name || 'Vendor'} · {shortDate(po.created_at)}</span></div><div className="po-side"><strong>{money(po.subtotal)}</strong><StatusPill status={po.status} /></div></div>)}{!recentOrders.length && <EmptyState title="No purchase orders" text="New orders will show up here." />}</div><div className="orders-total"><div><span>Created PO value</span><strong>{money(purchaseOrders.filter(po => po.status === 'created').reduce((sum, po) => sum + Number(po.subtotal || 0), 0))}</strong></div><div className="total-icon"><ArrowDownRight size={19} /></div></div></section></div>
    <div className="bottom-note"><ShieldCheck size={16} /><span>Vendor access is separated by account. Product approvals and PO history are recorded in the database.</span><span className="note-spacer" /><span className="version-label">PORTAL · MVP</span></div>
  </>;
}

function StatCard({ icon: Icon, label, value, detail, tone }) { return <div className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={19} strokeWidth={1.8} /></div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-detail"><span className={`stat-detail-dot ${tone}`} />{detail}</div></div>; }

function CatalogPage({ isManager, items, allItems, vendors, search, setSearch, statusFilter, setStatusFilter, vendorFilter, setVendorFilter, selected, updateSelection, stores, onStatus, onAdd, onCreatePO, busy, photoUrls, notes, setNotes, role }) {
  const selectedCount = Object.entries(selected).filter(([id, s]) => s.checked && allItems.find(i => i.id === id)?.status === 'approved').length;
  const totalSelected = allItems.filter(i => selected[i.id]?.checked && i.status === 'approved').reduce((sum, i) => sum + Number(i.rate || 0) * Number(selected[i.id]?.quantity || 1), 0);
  return <>
    <div className="page-heading-row"><div><div className="page-eyebrow">{isManager ? 'ASSORTMENT & BUYING' : 'VENDOR CATALOGUE'}</div><h1>{isManager ? 'Item catalog' : 'My items'}</h1><p>{isManager ? 'Review new products, approve the items you want, then build a purchase order.' : 'Upload new arrivals with photos, fabric, colour and pricing details.'}</p></div>{!isManager && <button className="primary-btn" onClick={onAdd}><Plus size={17} /> Add new item</button>}</div>
    <div className="catalog-toolbar"><div className="search-field"><Search size={17} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by item, SKU, colour or vendor…" /></div><div className="toolbar-filter"><Filter size={16} /><select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}><option value="all">All statuses</option><option value="submitted">Submitted</option><option value="approved">Approved</option><option value="rejected">Rejected</option><option value="archived">Archived</option></select></div>{isManager && <div className="toolbar-filter"><Users size={16} /><select value={vendorFilter} onChange={e => setVendorFilter(e.target.value)}><option value="all">All vendors</option>{vendors.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}</select></div>}<div className="result-count">{items.length} item{items.length !== 1 ? 's' : ''}</div></div>
    {isManager ? <>
      <div className="buying-helper"><div className="helper-icon"><ShoppingBag size={18} /></div><div><strong>Buying selection</strong><p>Approve submitted items first. Select approved items below, enter quantity and destination store, then create vendor-wise POs.</p></div><div className="helper-count"><strong>{selectedCount}</strong><span>selected</span></div></div>
      <section className="panel catalog-panel"><div className="table-wrap"><table className="data-table catalog-table"><thead><tr><th className="select-col">Select</th><th>Item details</th><th>Vendor</th><th>Fabric / Colour</th><th>Rate</th><th>Status</th><th>Order qty</th><th>Destination store</th><th>Review</th></tr></thead><tbody>{items.map(item => { const s = selected[item.id] || { quantity: 1, store_id: stores[0]?.id || '', checked: false }; const canSelect = item.status === 'approved'; return <tr key={item.id} className={s.checked ? 'selected-row' : ''}><td><input type="checkbox" className="checkbox" checked={Boolean(s.checked)} disabled={!canSelect} onChange={e => updateSelection(item.id, { checked: e.target.checked })} aria-label={`Select ${item.item_name}`} /></td><td><ProductCell item={item} photoUrl={photoUrls[item.id]} /></td><td><span className="vendor-inline"><span className="mini-avatar">{initials(item.vendor?.name)}</span>{item.vendor?.name || 'Vendor'}</span></td><td><div className="two-line"><strong>{item.fabric || '—'}</strong><span>{item.colour || '—'}</span></div></td><td className="rate-cell">{money(item.rate)}</td><td><StatusPill status={item.status} /></td><td><input className="qty-input" type="number" min="1" step="1" value={s.quantity} disabled={!canSelect} onChange={e => updateSelection(item.id, { quantity: Math.max(1, Number(e.target.value) || 1) })} /></td><td><select className="store-select" disabled={!canSelect} value={s.store_id} onChange={e => updateSelection(item.id, { store_id: e.target.value })}>{stores.map(store => <option key={store.id} value={store.id}>{store.store_name}</option>)}</select></td><td>{item.status === 'submitted' ? <div className="review-actions"><button className="approve-icon" title="Approve" onClick={() => onStatus(item, 'approved')}><Check size={16} /></button><button className="reject-icon" title="Reject" onClick={() => onStatus(item, 'rejected')}><X size={16} /></button></div> : item.status === 'approved' ? <span className="approved-mini"><CheckCircle2 size={14} /> Ready</span> : <span className="muted-cell">—</span>}</td></tr>; })}</tbody></table>{!items.length && <EmptyState title="No matching items" text="Adjust the filters or wait for a vendor to submit a new item." />}</div></section>
      <div className="po-builder"><div className="po-builder-left"><div className="po-builder-icon"><FileSpreadsheet size={20} /></div><div><strong>Create purchase order</strong><p>{selectedCount ? `${selectedCount} item(s) selected · Estimated value ${money(totalSelected)}` : 'Select approved items to start creating your PO.'}</p></div></div><div className="po-builder-right"><input className="notes-input" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Optional note to print on the PO Excel" /><button className="primary-btn" disabled={!selectedCount || busy} onClick={onCreatePO}>{busy ? 'Creating…' : 'Create purchase orders'} <ArrowRight size={16} /></button></div></div>
      <p className="workflow-hint"><FileSpreadsheet size={14} /> No email is sent. After creating POs, download each vendor-wise Excel file from the Purchase Orders register.</p>
    </> : <div className="item-card-grid">{items.map(item => <article className="item-card" key={item.id}><div className="item-image-wrap">{photoUrls[item.id] || item.demoPhoto ? <img src={photoUrls[item.id] || item.demoPhoto} alt={item.item_name} /> : <div className="image-placeholder"><Package size={26} /><span>Product photo</span></div>}<StatusPill status={item.status} /></div><div className="item-card-body"><div className="item-sku">{item.vendor_sku} · {item.category || 'Other'}</div><h3>{item.item_name}</h3><div className="item-attributes"><span>{item.fabric || 'Fabric not specified'}</span><i /> <span>{item.colour || 'Colour not specified'}</span></div><div className="item-card-foot"><strong>{money(item.rate)}</strong><span>Updated {shortDate(item.updated_at || item.created_at)}</span></div>{item.status === 'rejected' && <div className="rejection-note"><XCircle size={14} /> Contact the buying team for feedback.</div>}</div></article>)}{!items.length && <EmptyState title="Your catalogue is empty" text="Add your latest product with a photo and details to get started." action={<button className="primary-btn" onClick={onAdd}><Plus size={16} /> Add first item</button>} />}</div>}
  </>;
}

function OrdersPage({ isManager, orders, onDownload }) {
  return <><div className="page-heading-row"><div><div className="page-eyebrow">PROCUREMENT RECORDS</div><h1>{isManager ? 'Purchase orders' : 'My purchase orders'}</h1><p>{isManager ? 'Create one PO Excel file per vendor and download it whenever needed.' : 'View the purchase orders created for your vendor account and download the Excel file.'}</p></div>{isManager && <div className="export-chip"><FileSpreadsheet size={16} /> PO register</div>}</div><div className="stat-grid slim-stat-grid"><StatCard icon={FileSpreadsheet} label="Total orders" value={orders.length} detail="Visible in this workspace" tone="mint" /><StatCard icon={Download} label="Excel available" value={orders.filter(o => o.status === 'created').length} detail="Download on demand" tone="blue" /><StatCard icon={ShoppingBag} label="Vendor count" value={new Set(orders.map(o => o.vendor_id)).size} detail="In this PO register" tone="amber" /><StatCard icon={XCircle} label="Cancelled orders" value={orders.filter(o => o.status === 'cancelled').length} detail="Not active for buying" tone="violet" /></div><section className="panel orders-table-panel"><div className="panel-header"><div><h2>Order register</h2><p>PO value uses the item rate captured when the order was created.</p></div><div className="table-counter">{orders.length} records</div></div><div className="table-wrap"><table className="data-table"><thead><tr><th>Purchase order</th>{isManager && <th>Vendor</th>}<th>Created</th><th>Line count</th><th>PO value</th><th>Status</th><th>Action</th></tr></thead><tbody>{orders.map(po => <tr key={po.id}><td><div className="po-number-cell"><div className="po-icon small"><FileSpreadsheet size={16} /></div><div><strong>{po.po_number}</strong><span>{po.notes || 'Standard purchase order'}</span></div></div></td>{isManager && <td><span className="vendor-inline"><span className="mini-avatar">{initials(po.vendor?.name)}</span>{po.vendor?.name || 'Vendor'}</span></td>}<td className="muted-cell">{shortDate(po.created_at)}</td><td>{po.lines || po.purchase_order_lines?.length || '—'}</td><td className="rate-cell">{money(po.subtotal)}</td><td><StatusPill status={po.status} /></td><td><button className="icon-action" title={`Download ${po.po_number}.xlsx`} onClick={() => onDownload(po)}><Download size={16} /></button></td></tr>)}</tbody></table>{!orders.length && <EmptyState title="No purchase orders yet" text="Created purchase orders will appear in this register." />}</div></section><div className="bottom-note"><ShieldCheck size={16} /><span>Every purchase order is assigned a unique number and captures vendor, store, item, quantity and rate.</span></div></>;
}

function VendorsStoresPage({ vendors, stores }) {
  return <><div className="page-heading-row"><div><div className="page-eyebrow">MASTER DATA</div><h1>Vendors & stores</h1><p>Reference data used by the item catalogue and store-wise purchase orders.</p></div></div><div className="master-grid"><section className="panel master-panel"><div className="panel-header"><div><h2><Users size={18} /> Vendor directory</h2><p>Supplier accounts available in the portal</p></div><span className="table-counter">{vendors.length} vendors</span></div><div className="master-list">{vendors.map(v => <div className="master-row" key={v.id}><div className="master-avatar">{initials(v.name)}</div><div className="master-main"><strong>{v.name}</strong><span>{v.vendor_code || 'Vendor partner'}</span></div><div className="master-contact"><Mail size={14} /> {v.email}</div><span className="active-dot-label"><i /> Active</span></div>)}</div></section><section className="panel master-panel"><div className="panel-header"><div><h2><Store size={18} /> Store locations</h2><p>Destinations available when creating a PO</p></div><span className="table-counter">{stores.length} stores</span></div><div className="master-list">{stores.map(s => <div className="master-row" key={s.id}><div className="master-avatar store-avatar"><Building2 size={18} /></div><div className="master-main"><strong>{s.store_name}</strong><span>{s.store_code}</span></div><span className="active-dot-label"><i /> Active</span></div>)}</div></section></div><div className="bottom-note"><CircleHelp size={16} /><span>For the MVP, vendor/store master data is maintained in the Supabase database by an administrator.</span></div></>;
}

function ProductCell({ item, photoUrl }) { return <div className="product-cell"><div className="product-thumb">{photoUrl || item.demoPhoto ? <img src={photoUrl || item.demoPhoto} alt="" /> : <div className="thumb-placeholder"><Package size={17} /></div>}</div><div className="product-meta"><strong>{item.item_name}</strong><span>{item.vendor_sku} {item.category ? `· ${item.category}` : ''}</span></div></div>; }
function StatusPill({ status }) { const labels = { submitted: 'Submitted', approved: 'Approved', rejected: 'Rejected', archived: 'Archived', created: 'Created · Excel available', cancelled: 'Cancelled' }; return <span className={`status-pill status-${status || 'unknown'}`}><i />{labels[status] || status || 'Unknown'}</span>; }
function EmptyState({ title, text, action }) { return <div className="empty-state"><div className="empty-icon"><Package size={22} /></div><strong>{title}</strong><p>{text}</p>{action}</div>; }

function AddItemModal({ form, setForm, photo, setPhoto, fileRef, onClose, onSubmit, busy, vendor }) {
  const setField = (field, value) => setForm(prev => ({ ...prev, [field]: value }));
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><section className="item-modal"><div className="modal-header"><div><div className="page-eyebrow">NEW PRODUCT SUBMISSION</div><h2>Add a new item</h2><p>Share complete product details with the Purchase Manager.</p></div><button className="icon-button" onClick={onClose} aria-label="Close"><X size={19} /></button></div><form onSubmit={onSubmit}><div className="modal-form-layout"><div className="photo-uploader" onClick={() => fileRef.current?.click()} role="button" tabIndex={0} onKeyDown={e => { if (e.key === 'Enter') fileRef.current?.click(); }}><input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={e => setPhoto(e.target.files?.[0] || null)} />{photo ? <img src={URL.createObjectURL(photo)} alt="Selected product" /> : <><div className="upload-icon"><ImagePlus size={24} /></div><strong>Upload product photo</strong><span>JPG, PNG or WebP · Max 8 MB</span><span className="upload-cta"><Upload size={14} /> Browse image</span></>}</div><div className="form-fields-grid"><label className="field-wide">Vendor account<input value={vendor?.name || ''} disabled /></label><label>Item code / SKU<input value={form.vendor_sku} onChange={e => setField('vendor_sku', e.target.value)} placeholder="e.g. VND-1001" required /></label><label>Category<select value={form.category} onChange={e => setField('category', e.target.value)}><option>Saree</option><option>Suit Set</option><option>Fabric</option><option>Western Wear</option><option>Footwear</option><option>Accessories</option><option>Other</option></select></label><label className="field-wide">Item name<input value={form.item_name} onChange={e => setField('item_name', e.target.value)} placeholder="Enter product name" required /></label><label>Vendor rate (₹)<input type="number" min="0" step="0.01" value={form.rate} onChange={e => setField('rate', e.target.value)} placeholder="0.00" required /></label><label>Fabric<input value={form.fabric} onChange={e => setField('fabric', e.target.value)} placeholder="e.g. Soft silk" /></label><label>Colour<input value={form.colour} onChange={e => setField('colour', e.target.value)} placeholder="e.g. Wine / Gold" /></label><label>Size range<input value={form.size_range} onChange={e => setField('size_range', e.target.value)} placeholder="e.g. S–XXL / Free size" /></label><label className="field-wide">Other details<textarea value={form.other_details} onChange={e => setField('other_details', e.target.value)} placeholder="Design, work, dimensions, MOQ, delivery timeline…" rows="3" /></label></div></div><div className="modal-footer"><span><ShieldCheck size={15} /> Submitted items are visible to the buying team.</span><div><button type="button" className="secondary-btn" onClick={onClose}>Cancel</button><button type="submit" className="primary-btn" disabled={busy}>{busy ? 'Submitting…' : 'Submit item'} <ArrowRight size={16} /></button></div></div></form></section></div>;
}
